import Foundation

func longestNonRepeatingSubstring(_ inputString: String) -> Int {
    var maxLength = 0
    var start = 0
    var charIndex = [Character:Int]()
    
    for (index,char) in inputString.enumerated() {
        if let prevIndex = charIndex[char], prevIndex >= start {
            start = prevIndex + 1
        }
        charIndex[char] = index
        maxLength = max(maxLength, index - start + 1)
    }
    return maxLength
}

// Test
let inputString = "ABCDEFGABCDE"
let longestSubstring = longestNonRepeatingSubstring(inputString)
print(longestSubstring)

